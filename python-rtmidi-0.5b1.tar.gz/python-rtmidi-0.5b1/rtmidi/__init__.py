# -*- coding:utf-8 -*-
from __future__ import absolute_import
from .release import version as __version__
from ._rtmidi import *
from ._rtmidi import __doc__
del absolute_import
